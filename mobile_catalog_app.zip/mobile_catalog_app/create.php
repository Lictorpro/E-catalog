<?php
include 'db_conn.php';
$categories = [];
$result = mysqli_query($conn, "SELECT * FROM category;");
while($category = mysqli_fetch_object($result)){
    $categories[] = $category;
}
//Kod za COM STANDARDS
$comunication_standards =[];
$result_com_std = mysqli_query($conn, "SELECT * FROM comunication_standard;");
while($comunication_standard = mysqli_fetch_object($result_com_std)){
    $comunication_standards[] = $comunication_standard;
}
?>
<!DOCTYPE html>
<html>
  <head>

    <title>Mobile Catalog</title>
    <meta charset="utf-8">

    <meta name="viewport" content="width=device-width">
	 <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous"/>
    <link rel="stylesheet" href="./css/style.css">
  </head>
  <body>

    <header>
      <div class="container">
        
      <a class="home" href="index.php">
        <div id="mobile-logo">
          <h1><span class="highlight">Mobile Catalog</span></h1>
        </div>
        </a>
        
      </div>
    </header>

    <div id="add-form">
         <div class="container">   

        <h1>ADD NEW PHONE</h1>
        <form action="create_db.php" method="POST">
          <input type="text" id="brand" placeholder="BRAND" class="field" name="brand" required/>
          <div>
          <input type="text" id="model_name" placeholder="MODEL NAME" class="field" name="model_name" required/>
          <br>
          <input type="text" id="image_path" placeholder="IMAGE PATH (img/)" class="field" name="image_path" required/>
          <br>
          <input type="text" id="price" placeholder="PRICE" class="field" name="price" required/>
          <br>
          <input type="text" id="operating_system" placeholder="OPERATING SYSTEM" class="field" name="operating_system" required/>
          <br>
          <input type="text" id="ram" placeholder="RAM" class="field" name="ram" required/>
          <br>
          <input type="text" id="internal_memory" placeholder="INTERNAL MEMORY" class="field" name="internal_memory" required/>
          <br>
          <input type="text" id="screen_diagonal" placeholder="SCREEN DIAGONAL" class="field" name="screen_diagonal" required/>
          <br>
          <input type="text" id="battery" placeholder="BATTERY" class="field" name="battery" required/>
          <br>
          <input type="text" id="resolution" placeholder="RESOLUTION" class="field" name="resolution" required/>
          <br>
          <span>Front Camera:</span><select id="have_front_camera" name="front_camera" class="field select">
             <option value="1">Yes</option>
              <option value="0">No</option>
          </select>
          <br>
          <span>Back Camera:</span><select id="have_back_camera" name="back_camera" class="field select">
              <option value="1">Yes</option>
              <option value="0">No</option>
          </select>
          <br>
          <span>Category:</span><select id="category" name="category" class="field select">
          <?php
            foreach($categories as $category){
            echo "<option value='{$category->category_id}'>{$category->name}</option>";
        }

        ?>
          </select>
          <br>
          <div class="checkboxes">
          <?php
        foreach($comunication_standards as $comunication_standard){
            echo "<input type='checkbox' name='comunication_standards[]' value='{$comunication_standard->comunication_standard_id}'><span class='check'>{$comunication_standard->name}</span>";
        }

        ?>
        </div>
          <div class="button-center">
          <button type="submit" class="button_1">ADD</button>
        </div>


          </div>
        </form>
      </div>
</div>


      <footer>
      <div class="container">
        <p> Copyright &copy; 2021</p>
		
      </div>
	  
    </footer>

  </body>
</html>