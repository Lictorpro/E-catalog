<?php
include 'db_conn.php';
$mobile_id = (int) $_GET['id'];
$sql = "select * from mobile where mobile_id=$mobile_id;";
$result = mysqli_query($conn, $sql);
//Kod za komunikacione standarde
$com_std_sql = "select view__combined.name from view__combined where mobile_id = $mobile_id;";
$com_std_result = mysqli_query($conn, $com_std_sql);
$standards = [];
while($standard = mysqli_fetch_object($com_std_result)){
    $standards[] = $standard;
}

?>
<!DOCTYPE html>
<html>
  <head>

    <title>Mobile Catalog</title>
    <meta charset="utf-8">

    <meta name="viewport" content="width=device-width">
	 <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous"/>
    <link rel="stylesheet" href="./css/style.css">
  </head>
  <body>

    <header>
      <div class="container">
        
      <a class="home" href="index.php">
        <div id="mobile-logo">
          <h1><span class="highlight">Mobile Catalog</span></h1>
        </div>
        </a>
        
      </div>
    </header>
    



    <section id="boxes" style="border-bottom: none;">
    <div class="container">

    <h1> PHONE DETAILS </h1>
       
    <div class='box detail'>
    <div class='unutraboxa'>
    <?php
       
       while($row = mysqli_fetch_assoc($result)){
        
    echo "<img src='" . $row['image_path'] . "' alt='". $row['brand'] . " " . $row['model_name'] . "'>";

    echo "<h3>" . $row['brand'] . " " . $row['model_name'] . "</h3>";
    echo "<p>" . $row['price'] . " &#128;</p>";

        echo "</div>";
        echo "</div>";

echo "</div>";
echo "</section>";
    echo"</section>";

    echo"<div class='container-table'>";
    echo "<div class='mobile-table'>";

    
        echo "<table id='mobile-details'>";
        echo "<tr>";
        echo "<td>Operating System:</td>";
        echo "<td>" . $row['operating_system'] . "</td>";
        echo "</tr>";
        echo "<tr>";
        echo "<td>RAM:</td>";
        echo "<td>" . $row['ram'] . " GB</td>";
        echo "</tr>";
        echo "<tr>";
        echo "<td>Internal Memory:</td>";
        echo "<td>" . $row['internal_memory'] . " GB</td>";
        echo "</tr>";
        echo "<tr>";
        echo "<td>Screen Diagonal</td>";
        echo "<td>" . $row['screen_diagonal'] . " inches</td>";
        echo "</tr>";
        echo "<tr>";
        echo "<td>Battery:</td>";
        echo "<td>" . $row['battery'] . " mAh</td>";
        echo "</tr>";
        echo "<tr>";
        echo "<td>Resolution:</td>";
        echo "<td>" . $row['resolution'] . " px</td>";
        echo "</tr>";
        echo "<tr>";
        echo "<td>Front Camera:</td>";
        if($row['have_front_camera'] == 1){
            echo "<td>Yes</td>";
        }else{
            echo "<td>No</td>";
        }
        echo "</tr>";
        echo "<tr>";
        echo "<td>Back Camera:</td>";
        if($row['have_back_camera'] == 1){
            echo "<td>Yes</td>";
        }else{
            echo "<td>No</td>";
        }
        echo "</tr>";
        
        echo "<tr>";
        echo "<td>Communication Standards:</td>";
        echo "<td>";
        foreach($standards as $standard){

            echo "$standard->name ";
        }
        echo "</td>";

        echo "</tr>";
        echo "</table>";

        }
        mysqli_close($conn);
   
   ?>
    </div>
    </div>

    <footer style="border-top: 3px solid #45a29e;">
      <div class="container">
        <p> Copyright &copy; 2021</p>
		
      </div>
	  
    </footer>

  </body>
</html>