<?php
include 'db_conn.php';
//Ucitavanje Telefona
$mobile_id = (int) $_GET['id'];
$result_mobile = mysqli_query($conn, "SELECT * FROM mobile WHERE mobile_id=$mobile_id;");
$mobile = mysqli_fetch_object($result_mobile);


$categories = [];
$result = mysqli_query($conn, "SELECT * FROM category;");
while($category = mysqli_fetch_object($result)){
    $categories[] = $category;
}
//Kod za COM STANDARDS
$comunication_standards =[];
$result_com_std = mysqli_query($conn, "SELECT * FROM comunication_standard;");
while($comunication_standard = mysqli_fetch_object($result_com_std)){
    $comunication_standards[] = $comunication_standard;
}
//Ucitavanje vezne tabele - assoc = vezna tabela mobile_comunication_standard
$assocs = [];
$result_assoc = mysqli_query($conn, "SELECT * FROM mobile_comunication_standard;");
while($assoc = mysqli_fetch_object($result_assoc)){
    $assocs[] = $assoc;
}
?>
<!DOCTYPE html>
<html>
  <head>

    <title>Mobile Catalog</title>
    <meta charset="utf-8">

    <meta name="viewport" content="width=device-width">
	 <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous"/>
    <link rel="stylesheet" href="./css/style.css">
  </head>
  <body>

    <header>
      <div class="container">
        
      <a class="home" href="index.php">
        <div id="mobile-logo">
          <h1><span class="highlight">Mobile Catalog</span></h1>
        </div>
        </a>
        
      </div>
    </header>

    <div id="add-form">
         <div class="container">   

        <h1>EDIT PHONE</h1>
        <form action="update_db.php" method="POST">
        <input type="hidden" name="mobile_id" id="mobile_id" value="<?php echo $mobile->mobile_id; ?>">
          <input type="text" id="brand" placeholder="BRAND" class="field" name="brand" value="<?php echo $mobile->brand; ?>" required/>
          <div>
          <input type="text" id="model_name" placeholder="MODEL NAME" class="field" name="model_name" value="<?php echo $mobile->model_name; ?>" required/>
          <br>
          <input type="text" id="image_path" placeholder="IMAGE PATH (img/)" class="field" name="image_path" value="<?php echo $mobile->image_path; ?>" required/>
          <br>
          <input type="text" id="price" placeholder="PRICE" class="field" name="price" value="<?php echo $mobile->price; ?>" required/>
          <br>
          <input type="text" id="operating_system" placeholder="OPERATING SYSTEM" class="field" name="operating_system" value="<?php echo $mobile->operating_system; ?>" required/>
          <br>
          <input type="text" id="ram" placeholder="RAM" class="field" name="ram" value="<?php echo $mobile->ram; ?>" required/>
          <br>
          <input type="text" id="internal_memory" placeholder="INTERNAL MEMORY" class="field" name="internal_memory" value="<?php echo $mobile->internal_memory; ?>" required/>
          <br>
          <input type="text" id="screen_diagonal" placeholder="SCREEN DIAGONAL" class="field" name="screen_diagonal" value="<?php echo $mobile->screen_diagonal; ?>" required/>
          <br>
          <input type="text" id="battery" placeholder="BATTERY" class="field" name="battery" value="<?php echo $mobile->battery; ?>" required/>
          <br>
          <input type="text" id="resolution" placeholder="RESOLUTION" class="field" name="resolution" value="<?php echo $mobile->resolution; ?>" required/>
          <br>
          <span>Front Camera:</span><select id="have_front_camera" class="field select" name="front_camera">
          <?php
        if($mobile->have_front_camera == 1){
            echo "<option value='1' selected>Yes</option>";
            echo "<option value='0'>No</option>";
        }else{
            echo "<option value='0' selected>No</option>";
            echo "<option value='1'>Yes</option>";
        }
        ?>
          </select>
          <br>
          <span>Back Camera:</span><select id="have_back_camera" class="field select" name="back_camera">
          <?php
        if($mobile->have_back_camera == 1){
            echo "<option value='1' selected>Yes</option>";
            echo "<option value='0'>No</option>";
        }else{
            echo "<option value='0' selected>No</option>";
            echo "<option value='1'>Yes</option>";
        }
        ?>
          </select>
          <br>
          <span>Category:</span><select id="category" class="field select" name="category">
          <?php
        foreach($categories as $category){
            if($category->category_id == $mobile->category_id){
                echo "<option value='{$category->category_id}' selected>{$category->name}</option>";
            }else{
                echo "<option value='{$category->category_id}'>{$category->name}</option>";
            }
            
        }

        ?>
          </select>
          <br>
          <div class="checkboxes">
          <?php
        foreach($comunication_standards as $comunication_standard){
            echo "<input type='checkbox' name='comunication_standards[]' value='{$comunication_standard->comunication_standard_id}'><span class='check'>{$comunication_standard->name}</span>";
        }
        ?>
        </div>
          <div class="button-center">
          <button type="submit" class="button_1">UPDATE</button>
        </div>


          </div>
        </form>
      </div>
</div>


      <footer>
      <div class="container">
        <p> Copyright &copy; 2021</p>
		
      </div>
	  
    </footer>

  </body>
</html>