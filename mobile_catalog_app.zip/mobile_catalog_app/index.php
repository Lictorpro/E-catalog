<?php
session_start();
include 'db_conn.php';
if(isset($_GET['start_internal']) && isset($_GET['end_internal'])){
    $start_internal = $_GET['start_internal'];
    $end_internal = $_GET['end_internal'];
    $start_ram = $_GET['start_ram'];
    $end_ram = $_GET['end_ram'];

    $sql = "SELECT * FROM mobile WHERE (mobile.internal_memory BETWEEN $start_internal AND $end_internal)";
}
if(isset($_GET['start_ram']) && isset($_GET['end_ram'])){
    $sql .= "AND (mobile.ram BETWEEN $start_ram AND $end_ram)";
}
else{
    $sql = "SELECT * FROM mobile ORDER BY mobile.price ASC;";
}

$result = mysqli_query($conn, $sql);
?>
<!DOCTYPE html>
<html>
  <head>

    <title>Mobile Catalog</title>
    <meta charset="utf-8">

    <meta name="viewport" content="width=device-width">
	 <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous"/>
    <link rel="stylesheet" href="./css/style.css">
  </head>
  <body>

    <header>
      <div class="container">
        
      <a class="home" href="index.php">
        <div id="mobile-logo">
          <h1><span class="highlight">Mobile Catalog</span></h1>
        </div>
        </a>
        
        <nav>
          <ul>
          
          <?php
            if(isset($_SESSION['administrator_id'])){
              echo "<li><a>Hello " .$_SESSION['username']."</a></li>";
              echo "<li><a href='create.php'>Add new phone</a></li>";
              echo "<li><a href='logout.php'>Logout</a></li>";
            }else{
              echo "<li><a href='login.php'>Log In</a></li>";
    }

    ?>
          </ul>
        </nav>
      </div>
    </header>
    



    <section id="boxes">
      <div class="container">

        <h1> FILTER </h1>

        <section class="filter">
      <div class="filter-container">
        

        <form method="get">
        <div class="filter-section">
        <label>RAM:</label>
        <input type="text" placeholder="TO" name="end_ram" value="<?php if(isset($_GET['end_ram'])){echo $_GET['end_ram'];}else{echo "8";} ?>">
        <input type="text" placeholder="FROM" name="start_ram" value="<?php if(isset($_GET['start_ram'])){echo $_GET['start_ram'];}else{echo "0";} ?>">
        </div>
        
          
        <div class="filter-section">
        <label>Internal Memory:</label>
        <input type="text" placeholder="TO" name="end_internal" value="<?php if(isset($_GET['end_internal'])){echo $_GET['end_internal'];}else{echo "256";} ?>">
        <input type="text" placeholder="FROM" name="start_internal" value="<?php if(isset($_GET['start_internal'])){echo $_GET['start_internal'];}else{echo "0";} ?>">
        </div>
          
            
          <button type="submit" class="button_1">Filter</button>
        </form>
      </div>
    </section>

    <h1> PHONES WE OFFER </h1>

    
  
        
            <?php
            while($row = mysqli_fetch_assoc($result)){
            echo "<a style='text-decoration: none; color: #66fcf1;' href='mobile_details.php?id={$row['mobile_id']}'>";
            echo "<div class='box'>";
            echo "<div class='unutraboxa'>";
        echo "<img src='" . $row['image_path'] . "' alt='". $row['brand'] . " " . $row['model_name'] . "'>";
        echo "<h3>" . $row['brand'] . " " . $row['model_name'] . "</h3>";
        echo "<p>" . $row['price'] . " &#128;</p>";
        if(isset($_SESSION['administrator_id'])){
        echo "<a href='delete.php?id=" . $row['mobile_id'] . "'><button class='button_1 button-delete'><i class='fas fa-trash-alt'></i></button></a>";
        echo  "<a href='update.php?id=" . $row['mobile_id'] . "'> <button class='button_1 button-edit'><i class='fas fa-edit'></i></button></a>";
        }
        echo "</div>";
        echo "</div>";
            }
            ?>
         


       
    </section>


    

    <footer>
      <div class="container">
        <p> Copyright &copy; 2021</p>
		
      </div>
	  
    </footer>

  </body>
</html>