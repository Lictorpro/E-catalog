<?php
include 'db_conn.php';
$mobile_id = (int) $_POST['mobile_id'];
$brand = $_POST['brand'];
$model_name = $_POST['model_name'];
$image_path = $_POST['image_path'];
$price = $_POST['price'];
$operating_system = $_POST['operating_system'];
$ram = $_POST['ram'];
$internal_memory = $_POST['internal_memory'];
$screen_diagonal = $_POST['screen_diagonal'];
$battery = $_POST['battery'];
$resolution = $_POST['resolution'];
$have_front_camera = $_POST['front_camera'];
$have_back_camera = $_POST['back_camera'];
$category_id = $_POST['category'];
$sql = "UPDATE mobile SET brand='$brand', model_name='$model_name', image_path='$image_path', price='$price', operating_system='$operating_system', ram='$ram', internal_memory='$internal_memory', screen_diagonal='$screen_diagonal', battery='$battery', resolution='$resolution', have_front_camera='$have_front_camera', have_back_camera='$have_back_camera', category_id='$category_id' WHERE mobile_id=$mobile_id;";
$result = mysqli_query($conn, $sql);


if ($result) {


$comunication_standards = $_POST['comunication_standards'];
$sql = "DELETE FROM mobile_comunication_standard WHERE mobile_id=$mobile_id;";
$result = mysqli_query($conn, $sql);
foreach($comunication_standards as $comunication_standard){
    $sql_com_std = "INSERT INTO mobile_comunication_standard (mobile_id, comunication_standard_id) values ('$mobile_id', '$comunication_standard');";
    $result_com_std = mysqli_query($conn, $sql_com_std);
}
}
mysqli_close($conn);
header('Location: index.php');